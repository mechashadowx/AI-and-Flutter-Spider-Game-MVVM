import 'package:flutter/material.dart';

const primary100 = Color(0xFF9FEAF9);
const primary200 = Color(0xFF50717C);
const primary300 = Color(0xFF2B2E3B);
const primary400 = Color(0xFF1A1B23);
const accent = Color(0xFF24F390);

// Normal Buttons
const normalButtonHeight = 40.0;
const normalButtonWidth = 80.0;

// Floating Actions Button
const fabSize = 50.0;

// Font
const headerFontSize = 28.0;
const largeFontSize = 32.0;
const normalFontSize = 24.0;
const smallFontSize = 12.0;

// Radius
const normalRadius = 10.0;

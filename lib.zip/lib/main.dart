import 'package:flutter/material.dart';
import 'package:spider/src/view.dart';

void main() {
  runApp(App());
}
